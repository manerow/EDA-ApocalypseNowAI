#define GAME_NAME "ApocalypseNow2018"
#define VERSION   "3.0"
